
import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import bodyParser from 'body-parser';
import fs from 'fs';
import bs58 from 'bs58';
import { Connection, Keypair, PublicKey, clusterApiUrl, LAMPORTS_PER_SOL, SystemProgram, Transaction } from '@solana/web3.js';
import { createMint, getOrCreateAssociatedTokenAccount, mintTo } from '@solana/spl-token';

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json({limit: '1mb'}));

// Config from .env
const RPC_URL = process.env.RPC_URL || 'https://api.mainnet-beta.solana.com';
const COLLECTOR = new PublicKey(process.env.COLLECTOR_ADDRESS || 'BjtEmpjT4PF9kQNvY4baXK9M3jjQL65bPMVaNzrsRKVi');
const RELAYER_KEYPAIR_PATH = process.env.RELAYER_KEYPAIR_PATH || './relayer-keypair.json';
const MIN_CREATE_FEE = parseFloat(process.env.CREATE_FEE || '0.001'); // SOL
const MIN_FREEZE_FEE = parseFloat(process.env.FREEZE_FEE || '0.002'); // SOL

console.log('RPC:', RPC_URL);
const connection = new Connection(RPC_URL, 'confirmed');

function loadKeypair(path) {
  if(!fs.existsSync(path)) throw new Error('Relayer keypair not found at ' + path);
  const raw = JSON.parse(fs.readFileSync(path,'utf8'));
  return Keypair.fromSecretKey(Uint8Array.from(raw));
}

let relayerKeypair = null;
try {
  relayerKeypair = loadKeypair(RELAYER_KEYPAIR_PATH);
  console.log('Loaded relayer keypair:', relayerKeypair.publicKey.toBase58());
} catch(e) {
  console.warn('Relayer keypair not loaded. Create relayer-keypair.json and set RELAYER_KEYPAIR_PATH in .env to enable minting.');
}

// Utility: verify a transfer tx was made to COLLECTOR for at least amountSol
async function verifyPayment(txSig, amountSol) {
  if(!txSig) return false;
  try {
    const tx = await connection.getTransaction(txSig, {commitment: 'confirmed'});
    if(!tx) return false;
    const meta = tx.meta;
    if(!meta) return false;
    const accountKeys = tx.transaction.message.accountKeys.map(k=>k.toBase58());
    const idx = accountKeys.indexOf(COLLECTOR.toBase58());
    if(idx === -1) return false;
    const preBalances = meta.preBalances;
    const postBalances = meta.postBalances;
    const delta = (postBalances[idx] - preBalances[idx]) / LAMPORTS_PER_SOL;
    return delta >= amountSol - 1e-9;
  } catch(e) {
    console.error('verifyPayment error', e);
    return false;
  }
}

// Endpoint: verify fee + mint token (relayer does the mint)
app.post('/api/request-mint', async (req, res) => {
  /*
    Body expected:
    {
      "feeTx": "<signature>", // transaction signature where user paid collector
      "name": "My Token",
      "symbol": "MTK",
      "decimals": 6,
      "initialSupply": "1000000", // human units
      "recipient": "<user_pubkey>" // where minted tokens go
    }
  */
  try {
    const { feeTx, name, symbol, decimals, initialSupply, recipient } = req.body;
    if(!feeTx) return res.status(400).json({error: 'feeTx required'});

    // verify fee sent to collector
    const ok = await verifyPayment(feeTx, MIN_CREATE_FEE);
    if(!ok) return res.status(400).json({error: 'fee verification failed or insufficient'});

    if(!relayerKeypair) return res.status(500).json({error:'Relayer not configured on server. Set RELAYER_KEYPAIR_PATH.'});

    // Create mint and mint tokens to recipient
    const payer = relayerKeypair;
    const mintDecimals = Number(decimals || 6);
    const mint = await createMint(connection, payer, payer.publicKey, payer.publicKey, mintDecimals);
    const recipientPub = new PublicKey(recipient);
    const ata = await getOrCreateAssociatedTokenAccount(connection, payer, mint, recipientPub);
    const supplyUnits = BigInt(initialSupply || '1000000') * BigInt(10 ** mintDecimals);
    const sig = await mintTo(connection, payer, mint, ata.address, payer, supplyUnits);
    return res.json({ success: true, mint: mint.toBase58(), mintTx: sig });
  } catch(e) {
    console.error(e);
    return res.status(500).json({error: e.message});
  }
});

// Endpoint: verify fee + (placeholder) create liquidity
app.post('/api/request-add-liquidity', async (req, res) => {
  /*
    Body expected:
      { feeTx, mintAddress, solAmount, tokenAmount, recipient }
    This endpoint will *not* automatically create a pool for you right now.
    It verifies fee then returns next steps and a status.
  */
  try {
    const { feeTx, mintAddress } = req.body;
    if(!feeTx) return res.status(400).json({error:'feeTx required'});
    const ok = await verifyPayment(feeTx, MIN_FREEZE_FEE); // use freeze fee threshold for liquidity as example
    if(!ok) return res.status(400).json({error:'fee verify failed'});

    // For safety, we don't auto-create pools here. Provide recommended steps.
    return res.json({ success: true, message: 'Fee verified. Please open Raydium and add liquidity manually; include this mint: ' + mintAddress });
  } catch(e) {
    console.error(e);
    return res.status(500).json({error: e.message});
  }
});

// Endpoint: verify fee + (placeholder) lock LP
app.post('/api/request-lock', async (req, res) => {
  try {
    const { feeTx, lpMint } = req.body;
    if(!feeTx) return res.status(400).json({error:'feeTx required'});
    const ok = await verifyPayment(feeTx, MIN_FREEZE_FEE);
    if(!ok) return res.status(400).json({error:'fee verify failed'});

    return res.json({ success: true, message: 'Fee verified. Open Team.Finance and lock LP: ' + lpMint });
  } catch(e) {
    console.error(e);
    return res.status(500).json({error: e.message});
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=>console.log('Relayer API listening on', PORT));
