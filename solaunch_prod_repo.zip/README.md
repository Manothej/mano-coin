# SOLaunch Hub — Relayer + Frontend (Prototype)

This repository contains:
- `backend/` — Node.js relayer API that can verify fee transactions and (if configured) create SPL mints on Solana mainnet using a relayer keypair.
- `frontend/` — Single-page demo that connects Phantom, collects user fees (on-chain), and calls the relayer API to request minting.

IMPORTANT: This repo is capable of **mainnet actions** and will spend real SOL if used on mainnet. **Test thoroughly on Devnet first.**

## Quickstart (local testing on Devnet — recommended)
1. Install deps for backend:
   ```bash
   cd backend
   npm install
   ```
2. Copy `.env.example` to `.env` and edit values. For devnet testing set:
   ```
   RPC_URL=https://api.devnet.solana.com
   ```
3. Create a relayer keypair for testing:
   ```bash
   node -e "import fs from 'fs'; import {Keypair} from '@solana/web3.js'; const kp = Keypair.generate(); fs.writeFileSync('relayer-keypair.json', JSON.stringify(Array.from(kp.secretKey))); console.log('Relayer pubkey:', kp.publicKey.toBase58())"
   ```
   Move the generated `relayer-keypair.json` into `backend/` and set `RELAYER_KEYPAIR_PATH` accordingly.

4. Start the backend:
   ```bash
   npm start
   ```
   Backend listens on port defined in `.env` (default 4000).

5. Serve frontend (simple static serve). From project root:
   ```bash
   npx http-server frontend -p 3000
   ```
   Open `http://localhost:3000` in a browser with Phantom connected to Devnet.

## How it works
- Frontend collects a native SOL fee from the user and returns the transaction signature.
- Frontend calls `POST /api/request-mint` on the relayer with `feeTx` and mint parameters.
- Relayer verifies the `feeTx` actually paid the required fee to the collector address by inspecting the transaction.
- If verified and `RELAYER_KEYPAIR_PATH` is configured, relayer creates a new mint and mints tokens to the `recipient` address.

## Security & Production
- NEVER store large funds in the relayer hot wallet.
- Use a hardware key or KMS for production private keys.
- Add CAPTCHA, rate limiting, and replay protection.
- Move collected fees to a multisig/cold storage on schedule.

## Limitations
- Programmatic pool creation and locking are complex and DEX/locker-specific. This repo provides placeholders and guidance but does not fully automate Raydium pool creation or Team.Finance locking. You can extend `backend/index.js` with Raydium SDK calls (requires careful testing).

## License
MIT
